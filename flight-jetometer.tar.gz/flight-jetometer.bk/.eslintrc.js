module.exports = { extends: ['tsgs'] };
