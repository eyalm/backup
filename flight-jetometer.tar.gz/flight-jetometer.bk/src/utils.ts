export function checkForRealityID(realityID: string) {
  if (realityID) return realityID;
  return 'default';
}
