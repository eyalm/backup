export const configMock = () => ({ get: () => undefined });
export const producerMock = {};
export const consumerMock = {};
export const redisMock = {};
